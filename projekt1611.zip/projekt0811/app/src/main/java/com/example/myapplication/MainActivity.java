package com.example.myapplication;
import java.security.SecureRandom;
import java.util.Arrays;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText imie;
    EditText nazwisko;
    EditText stanowisko;
    TextView wyswietl;
    TextView pokazhaslo;
    int ile;
    String[] litery = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","R","S","T","U","W","Q","X","Y","Z"};
    String[] znaki = {"$","#","@","!","%","&","*"};
    String[] cyfry = {"1","2","3","4","5","6","7","8","9","0"};


    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imie = findViewById(R.id.imie);
        nazwisko = findViewById(R.id.nazwisko);
        stanowisko = findViewById(R.id.stanowisko);
        wyswietl = findViewById(R.id.dane);
        pokazhaslo = findViewById(R.id.haslo);
        Button myButton = findViewById(R.id.zatwierdz);
        Button generuj = findViewById(R.id.generuj);

        generuj.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick1(view);
            }
        });

        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });
    }

    public void onButtonClick1(View view) {
        CheckBox cyferki = (CheckBox) findViewById(R.id.cyfry);
        CheckBox literki = (CheckBox) findViewById(R.id.litery);
        CheckBox znaczki = (CheckBox) findViewById(R.id.znaki);
        ile = Integer.parseInt(String.valueOf(findViewById(R.id.ile)));
        Boolean cbool = cyferki.isChecked();
        Boolean lbool = literki.isChecked();
        Boolean zbool = znaczki.isChecked();
        SecureRandom rand = new SecureRandom();
        String znak = null;
        String[] haslo = {};
        int i;
        if(zbool == true && lbool == true && cbool == true) {
         for(i=0; i<ile;i++){
             double jakiznak = Math.round((rand.nextDouble()*3));
             if (jakiznak == 0 || jakiznak == 1){
                int cyfra = rand.nextInt(26);
                znak = litery[cyfra];
             }
             if (jakiznak == 2){
                 int cyfra = rand.nextInt(10);
                 znak = cyfry[cyfra];
             }
             if (jakiznak == 3){
                 int cyfra = rand.nextInt(7);
                 znak = znaki[cyfra];
             }
             haslo[i] = znak;
         }
        }
        if(zbool == true && lbool == true && cbool == false) {
            for(i=0; i<ile;i++){
                double jakiznak = Math.round((rand.nextDouble()*3));
                if (jakiznak == 0 || jakiznak == 1){
                    int cyfra = rand.nextInt(26);
                    znak = litery[cyfra];
                }
                if (jakiznak == 3 || jakiznak == 2){
                    int cyfra = rand.nextInt(7);
                    znak = znaki[cyfra];
                }
                haslo[i] = znak;
            }
        }
        if(zbool == true && lbool == false && cbool == true) {
            for(i=0; i<ile;i++){
                double jakiznak = Math.round((rand.nextDouble()*3));
                if (jakiznak == 2 || jakiznak == 0){
                    int cyfra = rand.nextInt(10);
                    znak = cyfry[cyfra];
                }
                if (jakiznak == 3 || jakiznak == 1){
                    int cyfra = rand.nextInt(7);
                    znak = znaki[cyfra];
                }
                haslo[i] = znak;
            }
        }
        if(zbool == false && lbool == true && cbool == true) {
            for(i=0; i<ile;i++){
                double jakiznak = Math.round((rand.nextDouble()*3));
                if (jakiznak == 0 || jakiznak == 1){
                    int cyfra = rand.nextInt(26);
                    znak = litery[cyfra];
                }
                if (jakiznak == 2 || jakiznak == 3){
                    int cyfra = rand.nextInt(10);
                    znak = cyfry[cyfra];
                }

                haslo[i] = znak;
            }
        }
        if(zbool == true && lbool == false && cbool == false) {
            for(i=0; i<ile;i++){
                int cyfra = rand.nextInt(7);
                znak = znaki[cyfra];
                haslo[i] = znak;
            }
        }
        if(zbool == false && lbool == true && cbool == false) {
            for(i=0; i<ile;i++)
            {
                int cyfra = rand.nextInt(26);
                znak = litery[cyfra];
                haslo[i] = znak;
            }
        }
        if(zbool == false && lbool == false && cbool == true) {
            for(i=0; i<ile;i++)
            {
                int cyfra = rand.nextInt(10);
                znak = cyfry[cyfra];
                haslo[i] = znak;
            }
        }
        if(zbool == false && lbool == false && cbool == false) {
            for(i=0; i<ile;i++){
                znak = "X";
                haslo[i] = znak;
            }
        }
        String password = Arrays.toString(haslo);

    pokazhaslo.setText(password);
}

    public void onButtonClick(View view) {
        String tekst1 = imie.getText().toString();
        String tekst2 = nazwisko.getText().toString();
        String tekst3 = stanowisko.getText().toString();

        String wynik = "Nazywasz się " + tekst1 + " " + tekst2 + " Stanowisko: " + tekst3;

        wyswietl.setText(wynik);
    }

}

