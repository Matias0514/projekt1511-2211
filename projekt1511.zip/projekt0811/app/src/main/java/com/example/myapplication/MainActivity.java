package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText imie;
    EditText nazwisko;
    EditText stanowisko;
    TextView wyswietl;
    int ile;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imie = findViewById(R.id.imie);
        nazwisko = findViewById(R.id.nazwisko);
        stanowisko = findViewById(R.id.stanowisko);
        wyswietl = findViewById(R.id.dane);

        Button myButton = findViewById(R.id.zatwierdz);
        myButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onButtonClick(view);
            }
        });
    }


    public void onButtonClick(View view) {
        String tekst1 = imie.getText().toString();
        String tekst2 = nazwisko.getText().toString();
        String tekst3 = stanowisko.getText().toString();

        String wynik = "Nazywasz się " + tekst1 + " " + tekst2 + " Stanowisko: " + tekst3;

        wyswietl.setText(wynik);
    }

}


/*
id:
imie
nazwisko
stanowisko

ile

litery
cyfry
znaki

generuj
zatwierdz
 */